import { businessData } from '../data';

export default function Menu() {
  return (
    <section id="menu" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-serif font-bold text-choco mb-4">
            Menu Highlights
          </h2>
          <p className="text-lg text-choco/60 max-w-2xl mx-auto">
            Discover our most loved creations, from classic scoops to indulgent sundaes.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {businessData.menu.map((item, index) => (
            <div 
              key={index} 
              className="bg-cream rounded-2xl p-6 border border-choco/5 hover:shadow-xl hover:shadow-caramel/10 transition-all duration-300 group"
            >
              <div className="flex justify-between items-start mb-4">
                <h3 className="text-xl font-serif font-bold text-choco group-hover:text-strawberry transition-colors">
                  {item.name}
                </h3>
                <span className="text-lg font-bold text-caramel bg-caramel/10 px-3 py-1 rounded-full">
                  ₹{item.price}
                </span>
              </div>
              <p className="text-choco/70 leading-relaxed">
                {item.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
