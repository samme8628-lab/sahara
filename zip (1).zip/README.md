# InventoryManagerEnv (OpenEnv)

A real-world e-commerce inventory management environment implementing the OpenEnv specification.

## Environment Description
The agent acts as an inventory manager for an e-commerce store. It must balance stock levels across multiple products with different demand trends (stable, volatile, growing). The goal is to maximize profit by fulfilling customer demand while minimizing order costs and daily storage fees.

## Action Space
The agent submits a list of `OrderAction` objects per step:
- `product_id` (str): The ID of the product to order.
- `quantity` (int): The amount to order.

## Observation Space (State)
The state is a typed `EnvState` Pydantic model containing:
- `day` (int): Current day.
- `max_days` (int): Total days in the episode.
- `balance` (float): Current cash balance.
- `products` (Dict[str, ProductState]): Current stock, costs, prices, and demand trends for each product.
- `recent_sales` (Dict[str, int]): Sales volume from the previous day.

## Reward Function
The step reward is the normalized daily profit:
`Reward = (Revenue - Order Costs - Storage Costs) / 1000.0`
This provides a meaningful partial progress signal at every step, encouraging the agent to maintain profitability throughout the episode rather than just at the end.

## Tasks & Graders
- **EasyTask**: 1 product, stable demand, 10 days.
- **MediumTask**: 2 products, mixed demand, 30 days.
- **HardTask**: 3 products (including high-cost servers), growing/volatile demand, 60 days.

Graders evaluate the final state and return a normalized score from `0.0` to `1.0` based on the final profit relative to a theoretical maximum.

## Setup & Usage
```bash
pip install -r requirements.txt
python -m src.baseline
```

## Docker & Hugging Face Spaces
This repository includes a `Dockerfile` ready for deployment to Hugging Face Spaces (Docker Space).
```bash
docker build -t inventory-env .
docker run inventory-env
```
