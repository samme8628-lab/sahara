import random
from src.env import OrderAction
from src.tasks import EasyTask, MediumTask, HardTask

def run_baseline(task_class):
    task = task_class()
    env = task.setup()
    state = env.state()
    done = False
    history = []
    
    print(f"--- Running {task_class.__name__} ---")
    print(f"Initial Balance: ${state.balance:.2f}")

    while not done:
        actions = []
        # Simple heuristic agent: order if stock is low
        for pid, prod in state.products.items():
            if prod.stock < 10:
                # Order enough to get back to a safe buffer
                actions.append(OrderAction(product_id=pid, quantity=20 - prod.stock))
        
        state, reward, done, info = env.step(actions)
        history.append((actions, info))
    
    score = task.grade(state, history)
    print(f"Final Balance: ${state.balance:.2f}")
    print(f"Task Score (0.0 - 1.0): {score:.2f}\n")

if __name__ == "__main__":
    run_baseline(EasyTask)
    run_baseline(MediumTask)
    run_baseline(HardTask)
