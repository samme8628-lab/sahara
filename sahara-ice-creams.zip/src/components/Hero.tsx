import { motion } from 'motion/react';
import { businessData } from '../data';

export default function Hero() {
  return (
    <section className="relative min-h-[90vh] flex items-center justify-center overflow-hidden pt-20">
      {/* Background Image with Overlay */}
      <div className="absolute inset-0 z-0">
        <img 
          src="https://images.unsplash.com/photo-1563805042-7684c8e9e533?q=80&w=2000&auto=format&fit=crop" 
          alt="Ice cream background" 
          className="w-full h-full object-cover"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-choco/60 mix-blend-multiply"></div>
      </div>

      <div className="relative z-10 text-center px-4 max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          <span className="inline-block py-1 px-3 rounded-full bg-strawberry/20 text-cream border border-strawberry/30 text-sm font-medium tracking-wider uppercase mb-6 backdrop-blur-sm">
            {businessData.category}
          </span>
          <h1 className="text-5xl md:text-7xl lg:text-8xl font-serif font-bold text-cream mb-6 leading-tight">
            {businessData.tagline}
          </h1>
          <p className="text-lg md:text-xl text-cream/90 mb-10 max-w-2xl mx-auto font-light">
            {businessData.description}
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a 
              href="#menu" 
              className="px-8 py-4 bg-strawberry text-cream rounded-full font-medium hover:bg-strawberry/90 transition-colors shadow-lg shadow-strawberry/20"
            >
              Explore Our Menu
            </a>
            <a 
              href="#location" 
              className="px-8 py-4 bg-cream/10 text-cream backdrop-blur-md border border-cream/30 rounded-full font-medium hover:bg-cream/20 transition-colors"
            >
              Find Us
            </a>
          </div>
        </motion.div>
      </div>
      
      {/* Decorative wave at the bottom */}
      <div className="absolute bottom-0 left-0 right-0 w-full overflow-hidden leading-none z-10">
        <svg className="relative block w-full h-[50px] md:h-[100px]" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 120" preserveAspectRatio="none">
          <path d="M321.39,56.44c58-10.79,114.16-30.13,172-41.86,82.39-16.72,168.19-17.73,250.45-.39C823.78,31,906.67,72,985.66,92.83c70.05,18.48,146.53,26.09,214.34,3V120H0V95.8C59.71,118.08,130.83,120.22,189.14,109.28Z" className="fill-cream"></path>
        </svg>
      </div>
    </section>
  );
}
