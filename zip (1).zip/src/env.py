import random
from typing import List, Dict, Tuple, Any
from pydantic import BaseModel

class OrderAction(BaseModel):
    product_id: str
    quantity: int

class ProductState(BaseModel):
    stock: int
    daily_storage_cost: float
    order_cost: float
    sell_price: float
    demand_trend: str

class EnvState(BaseModel):
    day: int
    max_days: int
    balance: float
    products: Dict[str, ProductState]
    recent_sales: Dict[str, int]

class InventoryManagerEnv:
    def __init__(self, config: Dict[str, Any] = None):
        self.config = config or {}
        self.max_days = self.config.get("max_days", 30)
        self.initial_balance = self.config.get("initial_balance", 1000.0)
        self._state = None
        
        # Set seed for reproducibility in baseline
        if "seed" in self.config:
            random.seed(self.config["seed"])
            
        self.reset()

    def reset(self) -> EnvState:
        self._state = EnvState(
            day=0,
            max_days=self.max_days,
            balance=self.initial_balance,
            products={
                "laptop": ProductState(stock=10, daily_storage_cost=2.0, order_cost=500.0, sell_price=800.0, demand_trend="stable"),
                "mouse": ProductState(stock=100, daily_storage_cost=0.1, order_cost=10.0, sell_price=25.0, demand_trend="volatile")
            },
            recent_sales={"laptop": 0, "mouse": 0}
        )
        return self.state()

    def state(self) -> EnvState:
        return self._state

    def step(self, actions: List[OrderAction]) -> Tuple[EnvState, float, bool, Dict[str, Any]]:
        if self._state.day >= self._state.max_days:
            return self.state(), 0.0, True, {"msg": "Episode already finished"}

        reward = 0.0
        info = {}

        # 1. Process Orders (Costs)
        order_costs = 0.0
        for act in actions:
            if act.product_id in self._state.products and act.quantity > 0:
                prod = self._state.products[act.product_id]
                cost = prod.order_cost * act.quantity
                order_costs += cost
                prod.stock += act.quantity
                self._state.balance -= cost

        # 2. Simulate Demand & Sales (Revenue)
        revenue = 0.0
        for pid, prod in self._state.products.items():
            # Simple demand simulation based on trend
            base_demand = 2 if pid == "laptop" else 15
            if prod.demand_trend == "stable":
                demand = max(0, int(random.gauss(base_demand, base_demand * 0.2)))
            elif prod.demand_trend == "volatile":
                demand = max(0, int(random.gauss(base_demand, base_demand * 0.8)))
            elif prod.demand_trend == "growing":
                demand = max(0, int(base_demand + self._state.day * 0.5))
            else:
                demand = base_demand

            sold = min(demand, prod.stock)
            prod.stock -= sold
            rev = sold * prod.sell_price
            revenue += rev
            self._state.balance += rev
            self._state.recent_sales[pid] = sold

        # 3. Storage Costs
        storage_costs = 0.0
        for pid, prod in self._state.products.items():
            sc = prod.stock * prod.daily_storage_cost
            storage_costs += sc
            self._state.balance -= sc

        # Calculate step reward (Profit for the day)
        daily_profit = revenue - order_costs - storage_costs
        
        # Partial progress signal: reward is normalized daily profit
        # We scale it down to keep rewards roughly in [-1, 1] range per step
        reward = daily_profit / 1000.0

        self._state.day += 1
        done = self._state.day >= self._state.max_days

        info = {
            "daily_revenue": revenue,
            "daily_order_costs": order_costs,
            "daily_storage_costs": storage_costs,
            "daily_profit": daily_profit
        }

        return self.state(), reward, done, info
