import { useState } from 'react';
import { SetupForm } from './components/SetupForm';
import { InterviewChat } from './components/InterviewChat';
import { FeedbackReport } from './components/FeedbackReport';
import { InterviewContext } from './types';
import { Briefcase } from 'lucide-react';

type AppState = 'setup' | 'interview' | 'feedback';

export default function App() {
  const [appState, setAppState] = useState<AppState>('setup');
  const [context, setContext] = useState<InterviewContext | null>(null);
  const [finalFeedback, setFinalFeedback] = useState<string>('');

  const handleStartInterview = (newContext: InterviewContext) => {
    setContext(newContext);
    setAppState('interview');
  };

  const handleCompleteInterview = (feedback: string) => {
    setFinalFeedback(feedback);
    setAppState('feedback');
  };

  const handleRestart = () => {
    setContext(null);
    setFinalFeedback('');
    setAppState('setup');
  };

  return (
    <div className="min-h-screen flex flex-col">
      <header className="bg-white border-b border-slate-200 sticky top-0 z-10">
        <div className="max-w-5xl mx-auto px-4 h-16 flex items-center gap-2">
          <div className="bg-blue-600 p-2 rounded-lg text-white">
            <Briefcase size={20} />
          </div>
          <h1 className="text-xl font-semibold text-slate-900 tracking-tight">AI Interviewer</h1>
        </div>
      </header>

      <main className="flex-1 max-w-5xl w-full mx-auto p-4 md:p-6 flex flex-col">
        {appState === 'setup' && (
          <SetupForm onStart={handleStartInterview} />
        )}
        {appState === 'interview' && context && (
          <InterviewChat 
            context={context} 
            onComplete={handleCompleteInterview} 
          />
        )}
        {appState === 'feedback' && (
          <FeedbackReport 
            feedback={finalFeedback} 
            onRestart={handleRestart} 
          />
        )}
      </main>
    </div>
  );
}
