import { motion } from 'motion/react';
import { CheckCircle, RotateCcw } from 'lucide-react';
import Markdown from 'react-markdown';

interface FeedbackReportProps {
  feedback: string;
  onRestart: () => void;
}

export function FeedbackReport({ feedback, onRestart }: FeedbackReportProps) {
  return (
    <motion.div 
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      className="max-w-3xl mx-auto w-full mt-8"
    >
      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="p-8 border-b border-slate-100 bg-emerald-50/50 flex flex-col items-center text-center">
          <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mb-4">
            <CheckCircle size={32} />
          </div>
          <h2 className="text-2xl font-semibold text-slate-900 mb-2">Interview Complete!</h2>
          <p className="text-slate-600 max-w-lg">
            Great job completing the interview. Review your personalized feedback below to see your strengths and areas for improvement.
          </p>
        </div>
        
        <div className="p-8">
          <div className="prose prose-slate max-w-none markdown-body">
            <Markdown>{feedback}</Markdown>
          </div>
        </div>

        <div className="p-8 border-t border-slate-100 bg-slate-50 flex justify-center">
          <button
            onClick={onRestart}
            className="px-6 py-3 bg-white border border-slate-200 hover:border-slate-300 hover:bg-slate-50 text-slate-700 rounded-xl font-medium flex items-center gap-2 transition-all shadow-sm"
          >
            <RotateCcw size={18} />
            Start New Interview
          </button>
        </div>
      </div>
    </motion.div>
  );
}
