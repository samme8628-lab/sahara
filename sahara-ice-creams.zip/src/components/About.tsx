import { CheckCircle2 } from 'lucide-react';
import { businessData } from '../data';

export default function About() {
  return (
    <section id="about" className="py-20 bg-cream">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div className="relative">
            <div className="absolute inset-0 bg-caramel/20 rounded-3xl transform translate-x-4 translate-y-4"></div>
            <img 
              src="https://images.unsplash.com/photo-1570197781417-0a82375c9371?q=80&w=1000&auto=format&fit=crop" 
              alt="Ice cream shop interior" 
              className="relative rounded-3xl object-cover w-full h-[500px] shadow-xl"
              referrerPolicy="no-referrer"
            />
          </div>
          
          <div>
            <h2 className="text-4xl font-serif font-bold text-choco mb-6">
              More Than Just Ice Cream
            </h2>
            <p className="text-lg text-choco/70 mb-8 leading-relaxed">
              {businessData.description} We believe in creating moments of joy through our carefully crafted desserts. Every scoop is made with love and the finest ingredients.
            </p>
            
            <div className="grid grid-cols-2 gap-4">
              {businessData.features.map((feature, index) => (
                <div key={index} className="flex items-center gap-3">
                  <CheckCircle2 className="text-mint h-6 w-6 flex-shrink-0" />
                  <span className="font-medium text-choco">{feature}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
