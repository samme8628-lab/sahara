export const businessData = {
  name: "Sahara Ice Creams",
  category: "Ice Cream Parlor / Dessert Shop",
  tagline: "Taste the Chill of Happiness",
  description: "Sahara Ice Creams is a popular dessert spot in Mydhukur known for its wide range of ice creams, sundaes, milkshakes, and seasonal specials. It’s a favorite hangout for families, students, and late-night dessert lovers.",
  location: {
    address: "Opposite RTC Bus Stand, Main Road",
    city: "Mydhukur",
    state: "Andhra Pradesh",
    zip: "516172",
    country: "India",
    coordinates: {
      lat: 14.7321,
      lng: 78.3456
    }
  },
  contact: {
    phone: "+91 91234 56789",
    email: "saharaicecreams@gmail.com",
    website: "www.saharaicecreams.in"
  },
  hours: [
    { day: "Monday", hours: "11:00 AM – 10:30 PM" },
    { day: "Tuesday", hours: "11:00 AM – 10:30 PM" },
    { day: "Wednesday", hours: "11:00 AM – 10:30 PM" },
    { day: "Thursday", hours: "11:00 AM – 10:30 PM" },
    { day: "Friday", hours: "11:00 AM – 11:00 PM" },
    { day: "Saturday", hours: "11:00 AM – 11:30 PM" },
    { day: "Sunday", hours: "11:00 AM – 11:30 PM" }
  ],
  ratings: {
    average: 4.5,
    total: 214,
    reviews: [
      { text: "Best place in town for ice creams!", author: "Local Guide" },
      { text: "Chocolate brownie sundae is amazing.", author: "Sweet Tooth" },
      { text: "Affordable prices and quick service.", author: "Happy Customer" }
    ]
  },
  menu: [
    { name: "Chocolate Brownie Sundae", price: 150, description: "Warm brownie topped with vanilla ice cream and hot fudge." },
    { name: "Butterscotch Ice Cream", price: 80, description: "Classic creamy butterscotch with crunchy praline." },
    { name: "Oreo Milkshake", price: 120, description: "Thick shake blended with crushed Oreos and chocolate syrup." },
    { name: "Fruit Salad with Ice Cream", price: 140, description: "Fresh seasonal fruits served with a scoop of your choice." },
    { name: "Family Pack (1L)", price: 320, description: "Take home the joy with our 1-liter assorted family packs." }
  ],
  features: [
    "Dine-in",
    "Takeaway",
    "Family Seating",
    "Kids Friendly"
  ],
  paymentOptions: [
    "Cash",
    "UPI (PhonePe, Google Pay, Paytm)",
    "Debit/Credit Cards"
  ],
  socialMedia: {
    instagram: "@saharaicecreams",
    facebook: "fb.com/saharaicecreams"
  }
};
