import { MapPin, Clock, Phone, Mail } from 'lucide-react';
import { businessData } from '../data';

export default function Location() {
  return (
    <section id="location" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16">
          
          {/* Info Side */}
          <div>
            <h2 className="text-4xl font-serif font-bold text-choco mb-8">Visit Us</h2>
            
            <div className="space-y-8">
              <div className="flex gap-4">
                <div className="w-12 h-12 bg-strawberry/10 rounded-full flex items-center justify-center flex-shrink-0">
                  <MapPin className="text-strawberry w-6 h-6" />
                </div>
                <div>
                  <h3 className="font-bold text-choco text-xl mb-2">Location</h3>
                  <p className="text-choco/70 leading-relaxed">
                    {businessData.location.address}<br />
                    {businessData.location.city}, {businessData.location.state} {businessData.location.zip}<br />
                    {businessData.location.country}
                  </p>
                </div>
              </div>

              <div className="flex gap-4">
                <div className="w-12 h-12 bg-mint/20 rounded-full flex items-center justify-center flex-shrink-0">
                  <Clock className="text-mint w-6 h-6" />
                </div>
                <div>
                  <h3 className="font-bold text-choco text-xl mb-2">Opening Hours</h3>
                  <ul className="space-y-1 text-choco/70">
                    {businessData.hours.map((h, i) => (
                      <li key={i} className="flex justify-between w-48">
                        <span>{h.day}</span>
                        <span>{h.hours.split('–')[0].trim()} - {h.hours.split('–')[1].trim()}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              <div className="flex gap-4">
                <div className="w-12 h-12 bg-caramel/10 rounded-full flex items-center justify-center flex-shrink-0">
                  <Phone className="text-caramel w-6 h-6" />
                </div>
                <div>
                  <h3 className="font-bold text-choco text-xl mb-2">Contact</h3>
                  <p className="text-choco/70">{businessData.contact.phone}</p>
                  <p className="text-choco/70">{businessData.contact.email}</p>
                </div>
              </div>
            </div>
          </div>

          {/* Map Side */}
          <div className="h-[400px] lg:h-auto min-h-[400px] bg-cream rounded-3xl overflow-hidden relative border border-choco/10">
            {/* Placeholder for actual map */}
            <div className="absolute inset-0 flex flex-col items-center justify-center text-choco/40 bg-cream/50">
              <MapPin className="w-16 h-16 mb-4" />
              <p className="font-medium">Map View</p>
              <p className="text-sm">{businessData.location.coordinates.lat}, {businessData.location.coordinates.lng}</p>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
}
