import { IceCream, Instagram, Facebook } from 'lucide-react';
import { businessData } from '../data';

export default function Footer() {
  return (
    <footer className="bg-choco text-cream py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-3 gap-12 mb-12">
          
          <div>
            <div className="flex items-center gap-2 mb-6">
              <IceCream className="h-8 w-8 text-strawberry" />
              <span className="font-serif text-2xl font-bold tracking-tight">
                Sahara
              </span>
            </div>
            <p className="text-cream/70 mb-6 max-w-xs">
              {businessData.tagline}
            </p>
            <div className="flex gap-4">
              <a href={`https://${businessData.socialMedia.instagram}`} className="w-10 h-10 rounded-full bg-cream/10 flex items-center justify-center hover:bg-strawberry transition-colors">
                <Instagram className="w-5 h-5" />
              </a>
              <a href={`https://${businessData.socialMedia.facebook}`} className="w-10 h-10 rounded-full bg-cream/10 flex items-center justify-center hover:bg-strawberry transition-colors">
                <Facebook className="w-5 h-5" />
              </a>
            </div>
          </div>

          <div>
            <h4 className="font-bold text-lg mb-6 font-serif">Quick Links</h4>
            <ul className="space-y-3 text-cream/70">
              <li><a href="#about" className="hover:text-strawberry transition-colors">About Us</a></li>
              <li><a href="#menu" className="hover:text-strawberry transition-colors">Our Menu</a></li>
              <li><a href="#reviews" className="hover:text-strawberry transition-colors">Reviews</a></li>
              <li><a href="#location" className="hover:text-strawberry transition-colors">Location & Hours</a></li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold text-lg mb-6 font-serif">Payment Options</h4>
            <ul className="space-y-3 text-cream/70">
              {businessData.paymentOptions.map((option, i) => (
                <li key={i}>{option}</li>
              ))}
            </ul>
          </div>

        </div>
        
        <div className="pt-8 border-t border-cream/10 text-center text-cream/50 text-sm">
          <p>&copy; {new Date().getFullYear()} {businessData.name}. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
