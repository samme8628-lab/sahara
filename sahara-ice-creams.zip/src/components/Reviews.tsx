import { Star } from 'lucide-react';
import { businessData } from '../data';

export default function Reviews() {
  return (
    <section id="reviews" className="py-24 bg-mint/20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <div className="flex items-center justify-center gap-2 mb-4">
            <span className="text-4xl font-bold text-choco">{businessData.ratings.average}</span>
            <div className="flex text-caramel">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className={`w-6 h-6 ${i < Math.floor(businessData.ratings.average) ? 'fill-current' : ''}`} />
              ))}
            </div>
          </div>
          <p className="text-choco/70 font-medium">Based on {businessData.ratings.total} reviews</p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {businessData.ratings.reviews.map((review, index) => (
            <div key={index} className="bg-white p-8 rounded-3xl shadow-sm relative">
              <div className="text-caramel mb-4 flex">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-5 h-5 fill-current" />
                ))}
              </div>
              <p className="text-choco/80 text-lg italic mb-6">"{review.text}"</p>
              <p className="font-bold text-choco font-serif">- {review.author}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
