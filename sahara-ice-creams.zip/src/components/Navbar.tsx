import { IceCream, Menu, X } from 'lucide-react';
import { useState } from 'react';
import { businessData } from '../data';

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <nav className="fixed w-full z-50 bg-cream/90 backdrop-blur-md border-b border-choco/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-20 items-center">
          <div className="flex items-center gap-2">
            <IceCream className="h-8 w-8 text-strawberry" />
            <span className="font-serif text-2xl font-bold text-choco tracking-tight">
              Sahara
            </span>
          </div>
          
          <div className="hidden md:flex space-x-8">
            <a href="#about" className="text-choco/80 hover:text-strawberry transition-colors font-medium">About</a>
            <a href="#menu" className="text-choco/80 hover:text-strawberry transition-colors font-medium">Menu</a>
            <a href="#reviews" className="text-choco/80 hover:text-strawberry transition-colors font-medium">Reviews</a>
            <a href="#location" className="text-choco/80 hover:text-strawberry transition-colors font-medium">Location</a>
          </div>

          <div className="md:hidden flex items-center">
            <button onClick={() => setIsOpen(!isOpen)} className="text-choco">
              {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      {isOpen && (
        <div className="md:hidden bg-cream border-b border-choco/10">
          <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
            <a href="#about" onClick={() => setIsOpen(false)} className="block px-3 py-2 text-choco hover:text-strawberry font-medium">About</a>
            <a href="#menu" onClick={() => setIsOpen(false)} className="block px-3 py-2 text-choco hover:text-strawberry font-medium">Menu</a>
            <a href="#reviews" onClick={() => setIsOpen(false)} className="block px-3 py-2 text-choco hover:text-strawberry font-medium">Reviews</a>
            <a href="#location" onClick={() => setIsOpen(false)} className="block px-3 py-2 text-choco hover:text-strawberry font-medium">Location</a>
          </div>
        </div>
      )}
    </nav>
  );
}
