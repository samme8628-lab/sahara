export interface InterviewContext {
  jobTitle: string;
  jobDescription: string;
  experienceLevel: string;
}

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
}
