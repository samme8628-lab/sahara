from typing import Dict, Any
from .env import InventoryManagerEnv, EnvState

class BaseTask:
    def setup(self) -> InventoryManagerEnv:
        raise NotImplementedError

    def grade(self, final_state: EnvState, history: list) -> float:
        """Returns a score between 0.0 and 1.0"""
        raise NotImplementedError

class EasyTask(BaseTask):
    """Easy: Single stable product, 10 days. Goal: Don't go bankrupt, make some profit."""
    def setup(self) -> InventoryManagerEnv:
        self.env = InventoryManagerEnv({"max_days": 10, "initial_balance": 5000.0, "seed": 42})
        state = self.env.reset()
        state.products = {
            "mug": state.products["laptop"].model_copy(deep=True)
        }
        state.products["mug"].stock = 50
        state.products["mug"].order_cost = 2.0
        state.products["mug"].sell_price = 10.0
        state.products["mug"].daily_storage_cost = 0.1
        state.products["mug"].demand_trend = "stable"
        return self.env

    def grade(self, final_state: EnvState, history: list) -> float:
        profit = final_state.balance - 5000.0
        if profit <= 0:
            return 0.0
        # Max possible profit roughly ~ 10 days * 10 demand * $8 margin = $800
        return min(1.0, profit / 500.0)

class MediumTask(BaseTask):
    """Medium: Two products, 30 days. Balance volatile and stable demand."""
    def setup(self) -> InventoryManagerEnv:
        self.env = InventoryManagerEnv({"max_days": 30, "initial_balance": 2000.0, "seed": 42})
        return self.env

    def grade(self, final_state: EnvState, history: list) -> float:
        profit = final_state.balance - 2000.0
        if profit <= 0:
            return 0.0
        return min(1.0, profit / 2000.0)

class HardTask(BaseTask):
    """Hard: 3 products, 60 days, growing and volatile trends. High storage costs."""
    def setup(self) -> InventoryManagerEnv:
        self.env = InventoryManagerEnv({"max_days": 60, "initial_balance": 5000.0, "seed": 42})
        state = self.env.reset()
        state.products["server"] = state.products["laptop"].model_copy(deep=True)
        state.products["server"].stock = 5
        state.products["server"].order_cost = 2000.0
        state.products["server"].sell_price = 3500.0
        state.products["server"].daily_storage_cost = 50.0
        state.products["server"].demand_trend = "growing"
        return self.env

    def grade(self, final_state: EnvState, history: list) -> float:
        profit = final_state.balance - 5000.0
        # Very easy to lose money on servers due to storage costs
        if profit <= 0:
            return 0.0
        return min(1.0, profit / 10000.0)
